# Nilesh
This is the project on Cryptocurrency price prediction usin machine learning using a hybrid approach

Abstract:

To predict Cryptocurrency price at different frequencies using machine learning techniques, we first download the dataset from a trusted website which keeps all the data 
of various cryptocurrencies then we classify various Cryptocurrencies by the dataset that is according to the available price. We extract the basic trading features 
acquired from a cryptocurrency exchange are used for 1 month price prediction. Machine learning algorithms including ARIMA and SVR models for Cryptocurrency’s daily 
price prediction with high-dimensional features achieve an accuracy of 93% and 94% respectively, outperforming more complicated machine learning algorithms. Compared
with benchmark results for daily price prediction, we achieve a better performance, with the highest accuracy of the machine learning algorithm of 97%. Our Hybrid 
Machine learning model including Support Vector Regression and Autoregressive integrated moving average for One month’s Cryptocurrency price prediction is superior to  
other Machine learning methods, with accuracy reaching 97%. Our investigation of Cryptocurrency price prediction can be considered a pilot study of the importance of the
sample dimension in machine learning techniques.


Extract the rar file for detailed project.
